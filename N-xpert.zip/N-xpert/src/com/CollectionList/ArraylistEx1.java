package com.CollectionList;

import java.util.ArrayList;
import java.util.Iterator;

public class ArraylistEx1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> al=new ArrayList<>();
		al.add(10);
		al.add(15);
		al.add(16);
		al.add(11);
		al.add(10);
		al.add(36);
		al.add(74);
		
		for(Integer mm:al) {
			System.out.println(mm);
		}
		System.out.println("-------------");
		al.forEach(m->{
			System.out.println(m);
		});
	}
	

}
