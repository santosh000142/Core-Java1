package com.CollectionList;

import java.util.ArrayList;

public class ArraylistEx2 {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<>();
		al.add("virat");
		al.add("Rohit");
		al.add("mallinga");
		al.add("Rahul");
		al.add("ABD");
		al.add("bhuvi");
		al.add("Bumrah");
		al.add("Rishabh");
		
//for each loop
		for(String ak:al) {
			System.out.println(ak);
		}
		System.out.println("----------------");
  //by using lambada expression
		al.forEach(m->{
			System.out.println(m);
		});
		
	System.out.println("------------------");
//by using method referance
al.forEach(System.out::println);

}}
