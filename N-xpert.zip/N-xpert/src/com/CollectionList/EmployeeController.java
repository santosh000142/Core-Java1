package com.CollectionList;

import java.util.ArrayList;
import java.util.Iterator;

public class EmployeeController {

	public static void main(String[] args) {
		ArrayList<Employee> al=new ArrayList<>();
		al.add(new Employee(11, "santosh", 25));
		al.add(new Employee(12, "Rohit", 30));
		al.add(new Employee(14, "Rahul", 35));
		al.add(new Employee(15, "mallinga",38 ));
		al.add(new Employee(16, "virat", 32));
		al.add(new Employee(18, "bhuvi", 29));
		al.add(new Employee(14, "Yuraj", 34));
		al.add(new Employee(19, "Bumrah",39 ));
		
//by using method referance
al.forEach(System.out::println);

System.out.println("-----------------------------------------");
		
//by using for each loop
for(Employee cc:al) {
	System.out.println(cc);
}
System.out.println("------------------------------------------");
Iterator<Employee> it=al.iterator();
while(it.hasNext()) {
	System.out.println(it.next());
}
System.out.println("------------------------------------------");
//by using lambada expression

al.forEach(h->{
	System.out.println(h);
});
System.out.println("__________________________________________");
//by using for loop
for(int i=0;i<al.size();i++) {
	System.out.println(al.get(i));
}
	}

}
