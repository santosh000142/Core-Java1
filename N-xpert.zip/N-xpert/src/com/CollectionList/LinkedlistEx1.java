package com.CollectionList;


import java.util.LinkedList;

public class LinkedlistEx1 {

	public static void main(String[] args) {
	LinkedList<Integer> al=new LinkedList<>();
		al.add(50);
		al.add(12);
		al.add(10);
		al.add(11);
		al.add(10);
		al.add(36);
		al.add(84);
		
		for(Integer m:al) {
			System.out.println(m);
		}
		System.out.println("-------------");
		al.forEach(m->{
			System.out.println(m);
		});
	}
	}


