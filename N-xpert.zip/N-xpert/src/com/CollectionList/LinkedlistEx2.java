package com.CollectionList;

import java.util.LinkedList;

public class LinkedlistEx2 {

	public static void main(String[] args) {
		LinkedList<String> game=new LinkedList<>();
		game.add("boxing");
		game.add("tennis");
		game.add("shooting");
		game.add("sailing");
		game.add("cycling");
		game.add("swimming");
		game.add("sailling");
		game.add("cricket");
		
//for each loop
		for(String pp:game) {
		System.out.println(pp);
		}
		System.out.println("----------------");
//by using lambada expression
		game.forEach(p->{
		System.out.println(p);
		});
		
	    System.out.println("------------------");
//by using method referance
game.forEach(System.out::println);

	}

}
