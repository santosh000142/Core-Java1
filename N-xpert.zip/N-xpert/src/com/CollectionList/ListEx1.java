package com.CollectionList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class ListEx1 {

	public static void main(String[] args) {
		ArrayList<Integer> al=new ArrayList<>();
	al.add(10);
	al.add(3);
	al.add(8);
	al.add(1);
	al.add(4);
	al.add(7);
	al.add(2);

	//by using sort method
	
	Collections.sort(al);
	for(Integer nn:al) {
		System.out.println(nn);
	}

	}

}
