package com.CollectionList;

import java.util.ArrayList;
import java.util.Collections;

public class ListEx2 {
	public static void main(String[] args) {
		
	
	ArrayList<String> al=new ArrayList<>();
	al.add("virat");
	al.add("Rohit");
	al.add("mallinga");
	al.add("rahul");
	al.add("maxwell");
	al.add("kohali");
	al.add("Dhoni");

	//by using sort method
	
	Collections.sort(al);
	for(String nn:al) {
		System.out.println(nn);
	}
}
}