package com.CollectionList;

import java.util.ArrayList;
import java.util.Collections;

public class ListEx3 {

	public static void main(String[] args) {
		
		ArrayList<Integer> al=new ArrayList<>();
		al.add(10);
		al.add(3);
		al.add(8);
		al.add(11);
		al.add(41);
		al.add(17);
		al.add(82);

//max number
		
		int kk=Collections.max(al);
		System.out.println("max number  "+kk);
		
//min number
		int pp=Collections.min(al);
		System.out.println("minimum number  "+pp);
	}

}
