package com.CollectionList;

import java.util.ArrayList;
import java.util.Iterator;

public class Personcontroller {
 
	public static void main(String[] args) {
	ArrayList<Person> al=new ArrayList<>();
	Person pp=new Person(10, "santosh", 10000);
	Person pp1=new Person(11, "Rohit", 12000);
	Person pp2=new Person(12, "Rahul", 16000);
	Person pp3=new Person(13, "Virat", 11000);
	Person pp4=new Person(14, "mahesh", 18000);
	al.add(pp);
	al.add(pp1);
	al.add(pp2);
	al.add(pp3);
	al.add(pp4);
	
Iterator<Person> ww=al.iterator();
while(ww.hasNext()) {
System.out.println(ww.next());
	
}

System.out.println("______________________________________________");

//by using foreach method

al.forEach(q->{
	System.out.println(q);
});	

	}
	
	}



