package com.CollectionList;

public class Player {

	private int no;
	private String name;
	private long strikerate;
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Player(int no, String name, long strikerate) {
		super();
		this.no = no;
		this.name = name;
		this.strikerate = strikerate;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getStrikerate() {
		return strikerate;
	}
	public void setStrikerate(long strikerate) {
		this.strikerate = strikerate;
	}
	@Override
	public String toString() {
		return "Player [no=" + no + ", name=" + name + ", strikerate=" + strikerate + "]";
	}
	
}
