package com.CollectionList;

import java.util.ArrayList;

public class PlayerRun {

	public static void main(String[] args) {
		ArrayList<Integer> run=new ArrayList<>();
	    run.add(45);
		run.add(88);
		run.add(63);
		run.add(98);
		run.add(55);
		run.add(25);
		run.add(34);
		
		int sum=0;
		int avg = 0;
//find the avarage of run
	for(int i=0;i<run.size();i++) {
		sum=sum+run.get(i);
		avg=sum/run.size();
		
	}
	System.out.println("Total Run of Avarage "+avg);
	}

}
