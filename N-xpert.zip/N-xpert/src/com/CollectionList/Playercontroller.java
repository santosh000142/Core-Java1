package com.CollectionList;

import java.util.Iterator;
import java.util.Vector;

public class Playercontroller {

	public static void main(String[] args) {
		Vector<Player> pl=new Vector<>();
		pl.add(new Player(45, "rohit", 135));
		pl.add(new Player(18, "virat", 144));
		pl.add(new Player(07, "dhoni", 102));
		pl.add(new Player(17, "abd", 156));
		pl.add(new Player(33, "hardik", 125));
		pl.add(new Player(44, "rishabh", 185));
		
//by using for each loop
		for(Player mm:pl) {
			System.out.println(mm);
		}
System.out.println("-------------------------------------");
//by using for loop
	for(int i=0;i<pl.size();i++) {
		System.out.println(pl.get(i));
	}
	System.out.println("----------------------------------------");
	
//by using method refernce
	pl.forEach(System.out::println);
	System.out.println("----------------------------------------");
 //iterator
	Iterator<Player> mm=pl.iterator();
	while(mm.hasNext()) {
		System.out.println(mm.next());
	}
System.out.println("----------------------------------------");

//by using lambada expression
pl.forEach(a->{
	System.out.println(a);
});
	
	}

}
