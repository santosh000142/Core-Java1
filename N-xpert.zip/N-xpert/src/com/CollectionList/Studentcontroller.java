package com.CollectionList;

import java.util.Iterator;
import java.util.LinkedList;

public class Studentcontroller {

	public static void main(String[] args) {
LinkedList<Student> st=new LinkedList<>();
st.add(new Student(21, "santosh", 45));
st.add(new Student(54, "rohan", 77));
st.add(new Student(21, "sagar", 87));
st.add(new Student(23, "Tushar", 89));
st.add(new Student(24, "virat", 63));

//by using method referance
st.forEach(System.out::println);
System.out.println("______________________________________");

//by using for loop
for(int i=0;i<st.size();i++) {
	System.out.println(st.get(i));
}
	System.out.println("______________________________________");

Iterator<Student> bb=st.iterator();
while(bb.hasNext()) {
	System.out.println(bb.next());
}
System.out.println("______________________________________");

//by using lambada
st.forEach(k->{
	System.out.println(k);
});
}
 


	}


