package com.CollectionList;

import java.util.Vector;

public class VectorEx {

	public static void main(String[] args) {
		
		
		Vector<Integer> al=new Vector<>();
		al.add(10);
		al.add(45);
		al.add(16);
		al.add(91);
		al.add(39);
		al.add(36);
		al.add(64);
		
		for(Integer kk:al) {
			System.out.println(kk);
		}
		System.out.println("-------------");
		al.forEach(m->{
			System.out.println(m);
		});
	}

}
