package com.CollectionList;


import java.util.LinkedList;

public class VectorEx2 {

	public static void main(String[] args) {
		LinkedList<String> al=new LinkedList<>();
		al.add("mango");
		al.add("Apple");
		al.add("lime");
		al.add("orange");
		al.add("lime");
		al.add("kiwi");
		al.add("cherry");
		al.add("strwabery");
		
	//for each loop
		for(String ss:al) {
			System.out.println(ss);
		}
		System.out.println("----------------");
   //by using lambada expression
		al.forEach(s->{
			System.out.println(s);
		});
		
	System.out.println("------------------");
//by using method referance
al.forEach(System.out::println);


	}

}
