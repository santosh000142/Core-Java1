package com.CollectionMap;

import java.util.HashMap;

public class HAshmapEx3 {

	public static void main(String[] args) {
		HashMap<String, Integer> kk=new HashMap<>();
		kk.put("one", 1);
		kk.put("two", 2);
		kk.put("three",3);
		kk.put("four", 4);
		kk.put("five", 5);
		kk.put("six", 6);
		kk.put("seven", 7);
		
//by using remove method
		kk.remove("two");
		
kk.forEach((m,n)->{
	System.out.print(m);
	System.out.print("=>");
	System.out.println(n);
});
	}

}
