package com.CollectionMap;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class Hashmap {

	public static void main(String[] args) {
		HashMap<String, Integer> hm=new HashMap<>();
		hm.put("virat", 18);
		hm.put("Rohit", 45);
		hm.put("Bhuvi", 33);
		hm.put("Yuraj", 25);
		hm.put("Dhoni", 78);
		hm.put("  ABD", 63);
		
		for(String mm:hm.keySet()) {
			System.out.println(mm+" => "+hm.get(mm));
	
		}
		System.out.println("===============================");
hm.forEach((m,n)->{
	System.out.print(m);
	System.out.print("=>");
	System.out.println(n);
});
System.out.println("-----------------------------------");

Iterator<String> mm=hm.keySet().iterator();


	}

}
