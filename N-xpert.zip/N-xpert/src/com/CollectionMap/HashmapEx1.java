package com.CollectionMap;

import java.util.HashMap;

public class HashmapEx1 {

	public static void main(String[] args) {
		
		
//using get method
	HashMap<String, Integer> kk=new HashMap<>();
	kk.put("one", 1);
	kk.put("two", 2);
	kk.put("three",3);
	kk.put("four", 4);
	kk.put("five", 5);
//present key
	System.out.println(kk.get("one"));
	
	
//absent key &return null
	System.out.println(kk.get("six"));
	}

}
