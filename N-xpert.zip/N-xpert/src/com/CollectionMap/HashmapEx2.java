package com.CollectionMap;

import java.util.HashMap;

public class HashmapEx2 {

	public static void main(String[] args) {
		HashMap<String, Integer> kk=new HashMap<>();
		kk.put("one", 1);
		kk.put("two", 2);
		kk.put("three",3);
		kk.put("four", 4);
		kk.put("five", 5);
		kk.put("six", 6);
		kk.put("seven", 7);
		
//by using contains key &present key--return Boolean value
		System.out.println(kk.containsKey("five"));
		
//by using contains key & absent key--return null
		System.out.println(kk.get("eight"));
	}

}
