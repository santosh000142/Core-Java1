package com.CollectionMap;

import java.util.TreeMap;

public class Treemap {

	public static void main(String[] args) {
		TreeMap<Integer, String> tm=new TreeMap<>();
		tm.put(25, "santosh");
		tm.put(28, "mahesh");
		tm.put(32, "Rohit");
		tm.put(45, "maxwell");
		tm.put(77, "mallinga");
		tm.put(48, "plasis");
		
///by using for each loop
		for(int mm:tm.keySet()) {
			System.out.println(mm+"=>"+tm.get(mm));
		}
		System.out.println("==============");
//by using for each method
tm.forEach((m,n)->{
	System.out.print(m);
	System.out.print("=>");
	System.out.println(n);
});


	}

}
