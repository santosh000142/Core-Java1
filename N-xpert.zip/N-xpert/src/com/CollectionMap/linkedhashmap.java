package com.CollectionMap;

import java.util.LinkedHashMap;

public class linkedhashmap {

	public static void main(String[] args) {
		LinkedHashMap<String, String> lh=new LinkedHashMap<>();
		lh.put("Bat", "ball");
		lh.put("hacky", "ball");
		lh.put("Swimming", "pull");
		lh.put("tennis", "ball");
		
	for(String kk:lh.keySet()) {
		System.out.println(kk+"  "+lh.get(kk));
	}
	System.out.println("=================");
	lh.forEach((m,n)->{
		System.out.print(m);
		System.out.print("=>");
		System.out.println(n);

	});

	}

}
