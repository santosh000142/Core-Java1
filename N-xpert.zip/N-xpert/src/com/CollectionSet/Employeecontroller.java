package com.CollectionSet;

import java.util.HashSet;
import java.util.Iterator;

public class Employeecontroller {

	public static void main(String[] args) {
		HashSet<Employee> hs=new HashSet<>();
		hs.add(new Employee(10, "santosh", 25));
		hs.add(new Employee(11, "virat", 30));
		hs.add(new Employee(12, "rohit", 25));
		hs.add(new Employee(14, "bhuvi", 40));
		hs.add(new Employee(16, "dhoni", 36));
		
//by using referance method 
hs.forEach(System.out::println);
		
System.out.println("-------------------------------------");

//by using for each loop
for(Employee nn:hs) {
	System.out.println(nn);
}
System.out.println("-------------------------------------");

//iterator
Iterator<Employee> kk=hs.iterator();
while(kk.hasNext()) {
	System.out.println(kk.next());
}
System.out.println("-------------------------------------");
//by using lambada 

hs.forEach(j->{
	System.out.println(j);
});
	}

}
