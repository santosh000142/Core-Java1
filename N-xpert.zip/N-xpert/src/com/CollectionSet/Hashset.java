package com.CollectionSet;

import java.util.HashSet;
import java.util.Iterator;

public class Hashset {

	public static void main(String[] args) {
		HashSet<Integer> hs=new HashSet<>();
		hs.add(12);
		hs.add(15);
		hs.add(12);
		hs.add(16);
		hs.add(19);
		hs.add(17);
		hs.add(12);
		hs.add(82);
		
//by using method refernce
hs.forEach(System.out::println);
System.out.println("_______________");

Iterator<Integer> hh=hs.iterator();
while(hh.hasNext()) {
	System.out.println(hh.next());
}
System.out.println("___________");

//by using lambada expression
hs.forEach(g->{
	System.out.println(g);
});
}
	}


