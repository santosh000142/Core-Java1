package com.CollectionSet;

import java.util.HashSet;
import java.util.Iterator;

public class HashsetEX2 {

	public static void main(String[] args) {
		HashSet<String> hs=new HashSet<>();
		hs.add("mango");
		hs.add("apple");
		hs.add("cherry");
		hs.add("watermillen");
		hs.add("strwaberry");

		//by using referance method
		hs.forEach(System.out::println);
		System.out.println("--------------");
//by using for each method
	for(String mm:hs) {
		System.out.println(mm);
	}
	System.out.println("--------------");
//ietrator
	Iterator<String> al=hs.iterator();
	while(al.hasNext()) {
		System.out.println(al.next());
	}
	System.out.println("--------------");
//by using lambada expression
	hs.forEach(r->{
		System.out.println(r);
	});
	}

}
