package com.CollectionSet;


import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedhasetEx1 {

	public static void main(String[] args) {
		LinkedHashSet<Integer> lh=new LinkedHashSet<>();
		lh.add(78);
		lh.add(71);
		lh.add(36);
		lh.add(96);
		lh.add(35);
		lh.add(69);
		lh.add(85);
		lh.add(78);
		
//by using method refernce
		lh.forEach(System.out::println);
System.out.println("_______________");

Iterator<Integer> hh=lh.iterator();
while(hh.hasNext()) {
	System.out.println(hh.next());
}
System.out.println("___________");

//by using lambada expression
lh.forEach(l->{
	System.out.println(l);
});
	}

}
