package com.CollectionSet;


import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedhasetEx3 {

	public static void main(String[] args) {
		LinkedHashSet<String> name=new LinkedHashSet<>();
		name.add("santosh");
		name.add("virat");
		name.add("rohit");
		name.add("rahul");
		name.add("mallinga");

		//by using referance method
		name.forEach(System.out::println);
		System.out.println("--------------");
//by using for each method
	for(String mm:name) {
		System.out.println(mm);
	}
	System.out.println("--------------");
//ietrator
	Iterator<String> al=name.iterator();
	while(al.hasNext()) {
		System.out.println(al.next());
	}
	System.out.println("--------------");
//by using lambada expression
	name.forEach(h->{
		System.out.println(h);
	});
	}

}
