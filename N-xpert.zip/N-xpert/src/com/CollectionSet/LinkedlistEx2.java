package com.CollectionSet;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedlistEx2 {

	public static void main(String[] args) {
		LinkedHashSet<Integer> mark=new LinkedHashSet<>();
		mark.add(88);
		mark.add(71);
		mark.add(36);
		mark.add(96);
		mark.add(35);
		mark.add(69);
		mark.add(85);
		mark.add(88);
		
//by using method refernce
		mark.forEach(System.out::println);
System.out.println("_______________");

Iterator<Integer> hh=mark.iterator();
while(hh.hasNext()) {
	System.out.println(hh.next());
}
System.out.println("___________");

//by using lambada expression
mark.forEach(l->{
	System.out.println(l);
});
System.out.println("------------");
//by using for loop
for(Integer ll:mark) {
	System.out.println(ll);
}
	}

}
