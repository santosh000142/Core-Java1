package com.CollectionSet;

public class Player {

int no;
String name;
int hundered;
public Player() {
	super();
	// TODO Auto-generated constructor stub
}
public Player(int no, String name, int hundered) {
	super();
	this.no = no;
	this.name = name;
	this.hundered = hundered;
}
public int getNo() {
	return no;
}
public void setNo(int no) {
	this.no = no;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getHundered() {
	return hundered;
}
public void setHundered(int hundered) {
	this.hundered = hundered;
}
@Override
public String toString() {
	return "Player [no=" + no + ", name=" + name + ", hundered=" + hundered + "]";
}

}
	
	

