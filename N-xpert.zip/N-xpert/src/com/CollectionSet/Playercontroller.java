package com.CollectionSet;


import java.util.HashSet;
import java.util.TreeSet;

public class Playercontroller {

	public static void main(String[] args) {

		HashSet<Player> pp=new HashSet<>();
		Player p=new Player(18, "virat", 71);
		Player p1=new Player(45, "Rohit", 41);
		Player p2=new Player(33, "Hardik", 21);
		Player p3=new Player(12, "mallinga", 89);
		pp.add(p);
		pp.add(p1);
		pp.add(p2);
		pp.add(p3);
		
pp.forEach(System.out::println);
System.out.println("-------------------------------------");

for(Player uu:pp) {
	System.out.println(uu);
}
System.out.println("------------------------------------");
//by using lambada
pp.forEach(u->{
	System.out.println(u);
});
}}
