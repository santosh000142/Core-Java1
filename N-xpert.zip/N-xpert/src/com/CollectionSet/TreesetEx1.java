package com.CollectionSet;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetEx1 {

	public static void main(String[] args) {
		TreeSet<Integer> ts=new TreeSet<>();
		ts.add(18);
		ts.add(35);
		ts.add(62);
		ts.add(96);
		ts.add(19);
		ts.add(97);
		ts.add(18);
		ts.add(82);
		
//by using method refernce
ts.forEach(System.out::println);
System.out.println("_______________");

Iterator<Integer> h=ts.iterator();
while(h.hasNext()) {
	System.out.println(h.next());
}
System.out.println("___________");

//by using lambada expression
ts.forEach(g->{
	System.out.println(g);
});
}
	}


