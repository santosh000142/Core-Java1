package com.CollectionSet;


import java.util.Iterator;
import java.util.TreeSet;

public class TreesetEx2 {

	public static void main(String[] args) {
		TreeSet<String> player=new TreeSet<>();
		 player.add("virat");
		 player.add("rahul");
		 player.add("bhuvi");
		 player.add("Yuraj");
		 player.add("mallinga");
		 player.add("virat");

//by using referance method
		 player.forEach(System.out::println);
		System.out.println("--------------");
//by using for each method
	for(String mm: player) {
		System.out.println(mm);
	}
	System.out.println("--------------");
//ietrator
	Iterator<String> al= player.iterator();
	while(al.hasNext()) {
		System.out.println(al.next());
	}
	System.out.println("--------------");
//by using lambada expression
	 player.forEach(r->{
		System.out.println(r);
	});

	}

}
