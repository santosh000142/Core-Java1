package com.Exception30;

public class ExceptionEx1 {

public static void main(String[] args) {
	
//Arithmatic exception 
	
	System.out.println(1);
	System.out.println(2);
	System.out.println(3);
	try {
	System.out.println(400/0);//---
	}catch(ArithmeticException e){
		//e.printStackTrace();
		System.out.println(e);
	}
	System.out.println(5);
	System.out.println(6);
	System.out.println(7);
	System.out.println(8);
	
		
		}}
	
		

