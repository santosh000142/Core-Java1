package com.Exception30;

public class ExceptionEx2 {

	

	public static void main(String[] args) {
		
//nullpointer exception
		
		String name="santosh";
		String city = null;
		int id=101;
		float marks=75;
		char grade='a';
		
		
		System.out.println(name);
		
		try {
		System.out.println(city.length());
		}catch(NullPointerException e){
			//e.printStackTrace();
			System.out.println(e);
		}
		finally {
			
			System.out.println("N-XPERT SOLUTION");
		}
		System.out.println(id);
		System.out.println(marks);
		System.out.println(grade);

	}

}
