package com.Exception30;

import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class ExceptionEx3 {

	public static void main(String[] args) {
	
	//file not found function
		
		try {
			FileInputStream file=new FileInputStream("d:/abc.txt");
		} catch (FileNotFoundException e) {
			
			//e.printStackTrace();
			System.out.println(e);
		}

	}

}


