package com.Exception30;

public class ExceptionEx4 {

	public static void main(String[] args) {
		
//single try block & multiple catch block
		
		String name="santosh";
		try {
			
			System.out.println(100/0);
			char c=name.charAt(10);
		}
		catch(StringIndexOutOfBoundsException se) {
			System.out.println(se);
		
		}
		catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println(ae);
		}
		catch(Exception e) {
			System.out.println(e);
		}

	}

}
