package com.Exception30;

public class ExceptionEx5 extends Exception{

//

private static int id[]= {18,45,33,77};		
private static String name[]= {"Virat","Rohit","Malinga","Rahul"};
private static double strikerate[]= {103,105,108,109};

public ExceptionEx5(String str) {
	super(str);
}

public static void main(String[] args) {
	
		try {
			
			System.out.println("id" +"=player" +"=strikerate");
			for(int i=0;i<4;i++) {
				System.out.println(id[i]+" "+name[i]+" "+strikerate[i]);
			if(strikerate[i]<106) {
			ExceptionEx5 ex=new ExceptionEx5("strike rate is less than 106");
			throw ex;
			}}
			} catch (ExceptionEx5 ex) {
			//ex.printStackTrace();
				System.out.println(ex);
			
		}
	}
	}


