package com.Exception30;

public class ExceptionEx6 {
	
//propagation exception
	

	void m1() {
		try {
			int div=100/0;
		} catch (ArithmeticException e) {
			//e.printStackTrace();
			System.out.println(e);
		}
		
	}
	void m2() {
		m1();
	}
	void m3() {
		m2();
	}
	public static void main(String[] args) {
		ExceptionEx6 ex=new ExceptionEx6();
		ex.m3();
		System.out.println("hallo india");


	}

}
