package com.Exception30;

public class ExceptionEx7 extends RuntimeException {

	//using throw keyword
		
		ExceptionEx7 (String msg){
			super(msg);
		}
		public static void main(String[] args) {
			int age=18;
     try {
	 if(age>20) {
		 
			throw new ExceptionEx7("you are not allow for voting");
	}else {
			System.out.println("you can vote succefully");
		}
		}
	catch(Exception e) {
				//e.printStackTrace();
				System.out.println(e);
			}
		}}

	


