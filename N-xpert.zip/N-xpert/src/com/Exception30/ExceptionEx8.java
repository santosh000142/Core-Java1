package com.Exception30;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionEx8 {
	
	//throws keyword
	
	static void takeinput() throws IOException  {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter your name");
		String name=br.readLine();
		System.out.println("your name is :--"+name);
	}

	public static void main(String[] args) //throws IOException
	{
		try {
			takeinput();
		} catch (IOException e) {
			
			e.printStackTrace();
		//	System.out.println(e);
		}

	}

}
