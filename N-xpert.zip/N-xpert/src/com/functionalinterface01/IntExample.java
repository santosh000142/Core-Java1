package com.functionalinterface01;

public interface IntExample {

	public int add(int a,int b);
}
