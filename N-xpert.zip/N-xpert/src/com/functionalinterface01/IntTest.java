package com.functionalinterface01;

public class IntTest {

	public static void main(String[] args) {
		
//multiple parameter in lambda expression	
		IntExample mm=(a,b)-> (a+b);
			System.out.println(mm.add(100, 200));
		
//multiple parameter  with data type in lambda expression
			IntExample mm1=(int a,int b)->(a*b);
			System.out.println(mm1.add(5, 6));

//substraction
			IntExample mm2=(a,b)->(a-b);
			System.out.println(mm2.add(25, 15));
//Division
			IntExample mm3=(a,b)->(a/b);
			System.out.println(mm3.add(78, 6));
			
		
	}}


