package com.functionalinterface01;

public class Test {
	
	//using static method
	
	public static  String saysomething() {
		System.out.println("hallo this is static method");
		return "Hallo India";
		
	}
	public static void main(String[] args) {
		
//--------------------------------------------------------------------------------
		//using lamda expression
		
		interfaceExample msg=()->{
			return "welcome to N-Expert";
			
		};
System.out.println(msg.add());
//------------------------------------------------------------------------------------------------


//referring static method
interfaceExample say=Test::saysomething;

//calling interface method
say.add();
	}

}
