package com.functionalinterface01;

@FunctionalInterface
public interface interfaceExample {
	
//Abstract method no parameter
	
	public String add();
}

