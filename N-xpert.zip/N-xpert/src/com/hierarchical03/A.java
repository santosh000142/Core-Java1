package com.hierarchical03;

public class A {

	public void printA() {
		
		System.out.println("my name is A");
	}
}
