package com.hierarchical03;

public class B extends A{

	public void printB() {
		System.out.println("my name is B");
	}
}
