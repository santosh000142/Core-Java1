package com.hierarchical03;

public class C extends A{

	public void printC() {
		System.out.println("my name is C");
	}
}
