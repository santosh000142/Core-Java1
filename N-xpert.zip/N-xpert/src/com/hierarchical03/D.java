package com.hierarchical03;

public class D extends A{

	public void printD() {
		System.out.println("my name is D");
	}
}
