package com.hierarchical03;

public class Test {

	public static void main(String[] args) {
		B bb=new B();
		bb.printA();
		bb.printB();
//------------------------
		C cc=new C();
		cc.printA();
		cc.printC();
//-------------------------
		D dd=new D();
		dd.printA();
		dd.printD();
      

	}

}
