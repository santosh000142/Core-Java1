package com.lambada27;

import java.awt.Button;
import java.awt.Frame;
import java.awt.event.ActionListener;

public class Buttonlist_newway1 {

	public static void main(String[] args) {
		Frame frame=new Frame("ActionListener java 8");
		
		Button b=new Button("onclick");
		b.setBounds(100, 200, 100, 100);
		b.addActionListener(e->{
			System.out.println("WELCOME TO --->");
		System.out.println("!N-XPERT SOLUTION !");
		
		});
		
		frame.add(b);
		frame.setSize(200, 200);
		frame.setLayout(null);
		frame.setVisible(true);

	}

}
