package com.lambada27;

import java.util.ArrayList;
import java.util.List;

public class CollectionExample {

	public static void main(String[] args) {
		List<String> al=new ArrayList<>();
		al.add("santosh");
		al.add("Rahul");
		al.add("Virat");
		al.add("Rohit");
		al.add("bhuvi");
		
//using lambada expression		
	al.forEach(e->{
		System.out.println(e);
	});	
	System.out.println("----------------------------");
	
//using  referance method
	
al.forEach(System.out::println);
//------------------------------------------------------------------------
System.out.println("-----------------------------------");

//using foreach loop
for(String mm:al) {
	System.out.println(mm);
	System.out.println("-----------------------------");
	
//using for loop
	for(int i=0;i<al.size();i++) {
		System.out.println(al.get(i));
	}
}
	}

}
