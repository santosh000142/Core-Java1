package com.lambada27;

@FunctionalInterface
public interface StringExample {
	
    public String show(String a,String b);
    
    
    
}
