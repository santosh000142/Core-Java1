package com.lambada27;

public class StringTest  {

	public static void main(String[] args) {
		
		//lambda expression with multiple argument
		StringExample mm=(a,b)->a+b;
        System.out.println("Result: "+mm.show("Hello ", "India"));

	}

}
