package com.multilevelinheritance02;

public class Animal {

	public void eat() {
		System.out.println(" Animal eating");
	}
}
