package com.multilevelinheritance02;

public class Animal_Test {

	public static void main(String[] args) {
		BabyDog bb=new BabyDog();
		bb.eat();
		System.out.println("_____________");
		bb.bark();
		System.out.println("____________");
		bb.weep();
	}

}
