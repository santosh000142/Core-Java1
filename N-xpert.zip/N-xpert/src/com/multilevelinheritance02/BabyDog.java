package com.multilevelinheritance02;

public class BabyDog extends Dog{

	public void weep() {
		System.out.println(" BabyDog Weeping");
	}
}
