package com.multilevelinheritance02;

public class Car extends Vehicle{

	public void petrol() {
		System.out.println("Car run on petrol");
		System.out.println("car small transport vehicle");
	}
}
