package com.multilevelinheritance02;

public class Dog extends Animal {

	public void bark() {
		System.out.println(" Dog Barking");
	}
}
