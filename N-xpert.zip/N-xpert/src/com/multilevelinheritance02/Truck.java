package com.multilevelinheritance02;

public class Truck extends Car{

	public void diesel() {
		System.out.println("Truck run on diesel");
		System.out.println("truck heavy transport vehicle");
		
	}
}
