package com.multilevelinheritance02;

public class Vehicle {

	public void type() {
		System.out.println("heavy transport vehilcle");
		System.out.println("small transport vehicle");
	}
}
