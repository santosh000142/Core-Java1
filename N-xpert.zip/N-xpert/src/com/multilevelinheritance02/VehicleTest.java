package com.multilevelinheritance02;

public class VehicleTest {

	public static void main(String[] args) {
		Truck tt=new Truck();
		tt.type();
		System.out.println("-------------------------------------");
		tt.petrol();
		System.out.println("------------------------------------");
		tt.diesel();

	}

}
