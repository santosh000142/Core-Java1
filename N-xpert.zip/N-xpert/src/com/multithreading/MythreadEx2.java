package com.multithreading;

public class MythreadEx2 extends Thread {
	
	@Override
	public void run() {
		for (int i=11;i<=20; i++) {
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			System.out.println("MythreadEx2--"+i);
			
		}
	}
public static void main(String[] args) {
	MythreadEx1 mm=new MythreadEx1();
	Thread th=new Thread(mm);
	
	MythreadEx2 mmm=new MythreadEx2();
	th.start();
	mmm.start();
	
}
}
