package com.multithreading;

public class MythreadEx4 extends Thread{

	@Override
	public void run() {
	for(int i=11;i<=20;i++) {
			try {
				Thread.sleep(1600);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			System.out.println("MythreadEx4--"+i);
		}
	}
	public static void main(String[] args) {
		MythreadEx3 mm=new MythreadEx3();
		Thread tt=new Thread(mm);
		
		MythreadEx4 kk=new MythreadEx4();
		kk.start();
		kk.setName("mythead");
		System.out.println(kk);
		tt.start();
	}
	
}
