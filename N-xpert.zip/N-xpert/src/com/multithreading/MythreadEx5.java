package com.multithreading;

public class MythreadEx5 {

	public static void main(String[] args) {
		System.out.println("programe start");
		
		int s=15+10;
		System.out.println(s);
		
		Thread t=Thread.currentThread();
		
		String tname=t.getName();
		
		System.out.println("currunt running thread is "+tname);
		
		System.out.println("programe ended");
		
		t.setName("mythread");
		
		System.out.println(t.getName());
		
		try {
			Thread.sleep(1000);
			
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		};
		System.out.println("programe ended");
	}

	public void produce_item(int i) {
		// TODO Auto-generated method stub
		
	}

}
