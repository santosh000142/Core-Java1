package com.multithreading;

public class MythreadEx6 {
int n;
	synchronized public void produce_item(int n) {
		this.n=n;
		System.out.println("produce : "+this.n);
	}
synchronized public  int consume_item() {
	System.out.println("consume : "+this.n);
	return this.n;
}
}
