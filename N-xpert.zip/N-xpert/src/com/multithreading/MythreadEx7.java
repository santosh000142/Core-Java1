package com.multithreading;

public class MythreadEx7 extends Thread{

	MythreadEx6 e;
	MythreadEx7(MythreadEx6 e){
		this.e=e;
	}
	@Override
	public void run() {
		int i=1;
		while (true) {
			this.e.produce_item(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			i++;
		}
	}
}
