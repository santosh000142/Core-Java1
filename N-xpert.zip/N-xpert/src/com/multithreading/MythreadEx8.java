package com.multithreading;

public class MythreadEx8 extends Thread {

	MythreadEx6 e;
	MythreadEx8(MythreadEx6 e){
		this.e=e;
	}
	@Override
	public void run() {
		while(true) {
			this.e.consume_item();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				
				e1.printStackTrace();
			}
			
		}
	}
}
