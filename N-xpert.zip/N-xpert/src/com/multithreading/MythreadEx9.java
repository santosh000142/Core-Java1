package com.multithreading;

public class MythreadEx9 {

	public static void main(String[] args) {
		MythreadEx6 m=new MythreadEx6();
		MythreadEx7 m1=new MythreadEx7(m);
		MythreadEx8 m2=new MythreadEx8(m);
		m1.start();
		m2.start();
	}

}
