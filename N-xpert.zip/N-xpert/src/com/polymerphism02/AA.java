package com.polymerphism02;

public class AA {

//same method name with return type
	
	public int add(int a,int b) {
		return a+b;
	}
	public String add(String a,String b) {
		return a+b;
	}
	public float add(float marks) {
		return marks;
		
	}
	public static void main(String[] args) {
	AA aa=new AA();
	System.out.println(aa.add(10, 15));
	System.out.println(aa.add("hallo ", "india"));
	System.out.println(aa.add(75));
	}
}
