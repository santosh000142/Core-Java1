package com.polymerphism02;

public class AB_Test {
	
//same method name with return type
	
	public static void main(String[] args) {
		B bb=new B();
		System.out.println(bb.show(10, 25));
		System.out.println(bb.show("M S Dhoni"));
		System.out.println(bb.show(78));
	//-------------------------------------------------------------------------
		System.out.println(bb.show(10, 20, 30));
		System.out.println(bb.show("welcome ", "N-xpert"));
		System.out.println(bb.show(75, 88));
		
		
}}
