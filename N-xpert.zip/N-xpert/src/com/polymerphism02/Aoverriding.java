package com.polymerphism02;

public class Aoverriding {

	public int show(int a,int b) {
		return a+b;
	}
	
	public String show(String a) {
		
		return a;
		
	}
	public long show(long mark) {
		return mark;
	}
}
