package com.polymerphism02;

public class B extends Aoverriding{

	public int show(int a,int b,int c) {
		return a+b+c;
		
	}
	public String show(String a,String b) {
		return a+b;
		
	}
	public long show(long mark,long percentage) {
		return mark+ percentage;
		
	}
	
}
