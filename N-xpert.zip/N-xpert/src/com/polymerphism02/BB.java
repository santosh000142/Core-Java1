package com.polymerphism02;

public class BB {

//same method name without return value
	
	public void add(String a) {
		System.out.println("my name is "+a);
	}
	public void add(int no,float strickrate ) {
		System.out.println("my no "+no);
		System.out.println("strikerate  "+strickrate);
	}
	public void add(long hundred) {
		System.out.println("total my hundred "+hundred);
	}
	public static void main(String[] args) {
		BB bb=new BB();
		bb.add("virat kohali");
		bb.add(18, 103);
		bb.add(71);
		
		System.out.println("___________________________");
		BB bb1=new BB();
		bb1.add("Rohit sharma");
		bb1.add(45, 106);
		bb1.add(69);
		
		System.out.println("___________________________");
		BB b=new BB();
		b.add("KL Rahul");
		b.add(33, 110);
		b.add(25);
	}
}
