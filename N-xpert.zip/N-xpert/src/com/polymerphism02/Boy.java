package com.polymerphism02;

public class Boy extends Humman {

	public void eat() {
		System.out.println("boy is eating");
	}
	public void eat(String drink) {
		System.out.println(drink);
	}
	public static void main(String[] args) {
		Boy bb=new Boy();
		bb.eat();
		bb.eat("milk");
	Humman hh=new Humman();
	hh.eat();
	hh.eat("mango");
		
		

	}

}
