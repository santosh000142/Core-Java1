package com.polymerphism02;

public class Humman {

	public void eat() {
		System.out.println("humman is eating");
	}
	public void eat(String fruit) {
		System.out.println(fruit);
	}
}
