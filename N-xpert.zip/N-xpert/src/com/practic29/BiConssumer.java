package com.practic29;

import java.util.function.BiConsumer;

public class BiConssumer {

	public static void main(String[] args) {
		
		BiConsumer<Integer, String> biconsumer=(a,b)->
		System.out.println("sum :--"+(a+b));
		biconsumer.accept(3, " santosh");

	}

}
