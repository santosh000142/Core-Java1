package com.practic29;

import java.util.function.BiFunction;

public class Bifunction {

	public static void main(String[] args) {
		
BiFunction<Integer, Integer, String> bifunction=(a,b)->"FINAL OUTPUT :--"+a+b;
String result =bifunction.apply(4, 7);
System.out.println(result);
	}

}
