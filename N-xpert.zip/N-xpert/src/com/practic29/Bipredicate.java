package com.practic29;

import java.util.function.BiPredicate;

public class Bipredicate {

	public static void main(String[] args) {
		
		BiPredicate<Integer, Integer> bipredicate=(a,b)->a+b >10;
		System.out.println("result : "+bipredicate.test(2, 3));
		
		
		
//---------------------------------------------------------------
		BiPredicate<Integer, String> bipredicate1=(a,b)->a+b.length()>10;
		System.out.println("result : "+bipredicate1.test(3, "santosh"));

	}

}
