package com.practic29;

import java.util.List;

public class Conssumerdemo2 {

	public static void main(String[] args) {
		
		List<Integer> list1=List.of(1,2,3,5,8,9,6,4,7);
		
		list1.stream().forEach(t->System.out.println("print ::" +t));

	}

}
