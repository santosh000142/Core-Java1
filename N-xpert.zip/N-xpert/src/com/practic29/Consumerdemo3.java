package com.practic29;

import java.util.function.Consumer;

public class Consumerdemo3 {

	public static void main(String[] args) {

		Consumer<String> showcolor=value ->{
			System.out.println(value);
			System.out.println(value);
			System.out.println(value);
		};
		showcolor.accept("Black");
		System.out.println("-----------");
		showcolor.accept("Red");
		System.out.println("-----------");
		showcolor.accept("yellow");
		
	}

}
