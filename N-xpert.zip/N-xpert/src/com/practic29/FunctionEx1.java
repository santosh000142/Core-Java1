package com.practic29;

import java.util.function.Function;

public class FunctionEx1 {

	public static void main(String[] args) {
Function<Integer, String> result=t->t*5+"---DATA MULTIPLE BY*5";
System.out.println(result.apply(3));
	}

}
