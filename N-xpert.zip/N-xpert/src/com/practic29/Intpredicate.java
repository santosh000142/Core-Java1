package com.practic29;

import java.util.function.BooleanSupplier;
import java.util.function.DoublePredicate;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntPredicate;
import java.util.function.IntSupplier;

public class Intpredicate {

	public static void main(String[] args) {
		
//intpredicate
		IntPredicate intpredicate=a->a>10;
		System.out.println("int predicate output  :-"+intpredicate.test(12));
//------------------------------------------------------------------------------------
		
//double predicate
		DoublePredicate  doublepredicate=a->a>10;
		System.out.println("Double predicate output  :-"+doublepredicate.test(12.5));
		
//-------------------------------------------------------------------------------------
//intconsumer
		IntConsumer  intconsumer=(a)->System.out.println("input value :--"+a);
		intconsumer.accept(10);
		
//-------------------------------------------------------------------------------------
//intsupplier
		IntSupplier intsupplier=()->10+20;
		System.out.println("by int supplier "+intsupplier.getAsInt());

//-------------------------------------------------------------------------------------
//	boolean supplier	
		BooleanSupplier booleansupplier=()->true;
		System.out.println("by boolean supplier --"+booleansupplier.getAsBoolean());
		
//-------------------------------------------------------------------------------------
//intfunction
		IntFunction<String> intfunction=a->"provide the value intfunction :--"+a;
		System.out.println(intfunction.apply(10));
	}

}
