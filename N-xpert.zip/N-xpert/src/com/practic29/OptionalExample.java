package com.practic29;

import java.util.Optional;



public class OptionalExample {

	public static void main(String[] args) {
		
		
		String st=null;
		

		Optional<String> op=Optional.ofNullable(st);
		System.out.println(op.isPresent());
		//System.out.println(op.get());
		
		System.out.println(op.orElse("no value"));

	}

}
