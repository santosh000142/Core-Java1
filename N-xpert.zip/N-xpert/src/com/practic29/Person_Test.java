package com.practic29;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Person_Test {

	public static void main(String[] args) {
		List<Person> list=new ArrayList<>();
		list.add(new Person("santosh", "Ahmednagar", 25));
		list.add(new Person("virat", "banglore", 32));
		list.add(new Person("Rohit", "Mumbai", 20));
		list.add(new Person("Dhoni", "Ranchi", 38));
		list.add(new Person("maxwell", "Austrilia", 28));
		list.add(new Person("AB devilers", "SAfica", 35));
		list.add(new Person("malinga", "shrilanka", 22));
		
	// 	
		list.forEach(w->{
			System.out.println(w);
		});
		System.out.println("----------------------------------------------------");
		
		//converting in list to set & using filter method ,person age more than 25
		Set<Person> list1=list.stream().filter(p->p.getAge()>25).collect(Collectors.toSet());
		list1.forEach(System.out::println);
	}

}
