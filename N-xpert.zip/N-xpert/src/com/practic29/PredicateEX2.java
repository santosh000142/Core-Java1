package com.practic29;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PredicateEX2 {

	public static void main(String[] args) {
		
		
		//find the element not start with A
		
		Predicate<String> str=s->s.startsWith("A");
		List<String> al=Arrays.asList("santosh","Abhishek","Rahul","virat","Ajinkya");
		
		List<String> list1=al.stream().filter(str.negate()).collect(Collectors.toList());
		list1.forEach(System.out::println);
	}

}
