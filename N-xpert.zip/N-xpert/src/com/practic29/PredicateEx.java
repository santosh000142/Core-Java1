package com.practic29;

import java.util.function.Predicate;

public class PredicateEx implements Predicate<Integer>{

	
	@Override
	public boolean test(Integer t) {
		if(t%2==0) {
			return true;
		}else {
			return false;
		}
		
	}
	public static void main(String[] args) {
		Predicate<Integer> pre=new PredicateEx();
		System.out.println(pre.test(11));
	}

}
