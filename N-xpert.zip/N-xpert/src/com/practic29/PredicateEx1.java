package com.practic29;

import java.util.function.Predicate;

public class PredicateEx1 {
	
//using lambada expression
	
	public static void main(String[] args) {
		
		Predicate<Integer> pre=(t)->{
			if(t%2!=0) {
				return true;
			}else {
			return false;
			}
		};
		System.out.println(pre.test(15));

		
		
//checking the length String & return true or false
		
		Predicate<String> checklength=str ->str.length()>7;
			
		System.out.println(checklength.test("santosh"));
		}
	}


