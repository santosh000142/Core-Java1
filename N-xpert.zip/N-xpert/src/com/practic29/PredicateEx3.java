package com.practic29;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PredicateEx3 {

	public static void main(String[] args) {
		
		Predicate<Integer> nogreaterthan10=x->x>10;
		Predicate<Integer> nolessthan20=x->x<20;
		
		List<Integer> al=List.of(1,5,2,89,6,4,7,15,63,71,12,11,2);
		
		List<Integer> list1=al.stream().
				filter(nogreaterthan10.and(nolessthan20))
				.collect(Collectors.toList());
		
		System.out.println("between 10 to 20");
		list1.forEach(System.out::println);
		

	}

}
