package com.practic29;

import java.util.function.Supplier;

public class SupplierDemo implements Supplier<String>{

	

	@Override
	public String get() {
		
		return "! WELCOME TO N-XPERT SOLUTION !";
	}
	public static void main(String[] args) {
		
		Supplier<String> suplier=new SupplierDemo();
		System.out.println(suplier.get());
	}

}
