package com.practic29;

import java.util.function.ToLongFunction;

public class Tolongfunction {

	public static void main(String[] args) {
		
		ToLongFunction<Integer> tlf=(a)->a+5;
		Integer a=6;
		System.out.println(tlf.applyAsLong(a));
	}

}
