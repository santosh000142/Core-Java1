package com.practic29;

import java.util.function.BinaryOperator;
import java.util.function.UnaryOperator;

public class UnaryandBinary_oprator {

	public static void main(String[] args) {
		
//unary oprator with String
		UnaryOperator<String> unary=x->"Hallo";
		System.out.println(unary.apply("india"));
	System.out.println("---------------");
//unary oprator with integer
		UnaryOperator<Integer> unary1=x->x+2;
		System.out.println(unary1.apply(5));		
		System.out.println("---------------");
//---------------------------------------------------------------------
//binary oprator with string
		BinaryOperator<String> binary=(a,b)->a+b;
		System.out.println(binary.apply("hallo"," india"));
		
		System.out.println("---------------");
//----------------------------------------------------------------------
//binary oprator with integer
		BinaryOperator<Integer> binary1=(a,b)->a+b;
		System.out.println(binary1.apply(5, 6));
	}

}
