package com.practice03;

import java.util.Comparator;

public class Agecomparator implements Comparator<Player> {

	@Override
	public int compare(Player o3, Player o4) {
		
		return o3.getAge()-o4.getAge();
	}

	

}
