package com.practice03;

import java.util.ArrayList;
import java.util.Collections;

public class EmployeeController {

	public static void main(String[] args) {
		
		ArrayList<Employee> al=new ArrayList<>();
		al.add(new Employee(18,"santosh", 10000));
		al.add(new Employee(12, "virat", 15000));
		al.add(new Employee(11, "Rohit", 11000));
		al.add(new Employee(14, "Dhoni", 9000));
		
//comparable by using sorting id
		Collections.sort(al);
		
		al.forEach(e->{
			System.out.println(e);
		});
	}

}
