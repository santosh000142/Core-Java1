package com.practice03;

import java.util.Comparator;

public class Playercomparator implements Comparator<Player>{

	@Override
	public int compare(Player o1, Player o2) {
		
		return o1.getId()-o2.getId();
	}

}
