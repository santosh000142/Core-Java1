package com.practice03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Playercontroller {

	public static void main(String[] args) {
		ArrayList<Player> pl=new ArrayList<>();
		pl.add(new Player(11, "santosh", 25));
		pl.add(new Player(21, "mahesh", 29));
		pl.add(new Player(12, "virat", 21));
		pl.add(new Player(10, "Rohit", 24));
		pl.add(new Player(18, "mallinga", 23));
	//sorting id wise
		//comparator
		Collections.sort(pl,new Playercomparator());
		pl.forEach(System.out::println);
		
		System.out.println("---------------------------------------");

//sorting name wise by using comparator
		List<Player> pl1=new ArrayList<>(pl);
		Collections.sort(pl1, new Namecomparator());
		pl1.forEach(a->{
			System.out.println(a);
		});
		
		System.out.println("-----------------------------------------");
//sorting age wise by using comparator
		List<Player> pl2=new ArrayList<>(pl);
		
		Collections.sort(pl2, new Agecomparator());
		pl2.forEach(System.out::println);
         
	}

}
