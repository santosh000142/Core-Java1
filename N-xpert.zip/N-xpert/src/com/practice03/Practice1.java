package com.practice03;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Practice1 {

	public static void main(String[] args) {
		List<Integer> al=List.of(12,51,41,82,63,76,45,56,74);
		
		
//max number 
	Integer mm=al.stream().max((a,b)->a.compareTo(b)).get();
System.out.println("maximum number----"+mm);

//min number
Integer kk=al.stream().min((c,d)->c.compareTo(d)).get();
System.out.println("minimum number-----"+kk);

//sorting number
al.stream().sorted().forEach(System.out::println);

//finding even number
List<Integer> tt=al.stream().filter(y->y%2==0).collect(Collectors.toList());
System.out.println("even number--"+tt);

//finding odd number
List<Integer> hh=al.stream().filter(y->y%2!=0).collect(Collectors.toList());
System.out.println("odd number--"+hh);

//more than 50
List<Integer> pp=al.stream().filter(k->k>50).collect(Collectors.toList());
System.out.println("more than--"+pp);

//less than 50
List<Integer> yy=al.stream().filter(w->w<50).collect(Collectors.toList());
System.out.println("less than--"+yy);
	}
}
