package com.practice03;

import java.util.List;

public class Practice2 {

	public static void main(String[] args) {
		List<String> sub=List.of("math","english","chemistry","physics","biology");
		
//by using method refernce
sub.forEach(System.out::println);

System.out.println("-------------");

//by sorting subject
sub.stream().sorted().forEach(System.out::println);

	}
}
