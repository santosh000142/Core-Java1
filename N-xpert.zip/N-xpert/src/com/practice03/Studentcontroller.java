package com.practice03;

import java.util.ArrayList;
import java.util.Collections;

public class Studentcontroller {

	public static void main(String[] args) {
		
		ArrayList<Student> al=new ArrayList<>();
		
		al.add(new Student(12, "santosh", 78));
		al.add(new Student(11, "mahesh", 66));
		al.add(new Student(15, "maxwell", 98));
		al.add(new Student(23, "Rohit", 74));
		al.add(new Student(14, "Rahul", 86));
		
//as it is print
		al.forEach(System.out::println);

		System.out.println("___________________________________________");
//shorting  mark wise
		Collections.sort(al);
	al.forEach(h->{
		System.out.println(h);
	});
	}

}
