package com.practice28;

import java.awt.Button;
import java.awt.Frame;

public class Buttonlist_newway {

	public static void main(String[] args) {
		Frame frame=new Frame("java 8");
		Button b=new Button("CLICK HERE");
		b.setBounds(50, 60, 100, 60);
		b.addActionListener(r->{
			System.out.println("! HALLO INDIA !");
		});
		frame.add(b);
		frame.setSize(200,200);
		frame.setLayout(null);
		frame.setVisible(true);
	}

}
