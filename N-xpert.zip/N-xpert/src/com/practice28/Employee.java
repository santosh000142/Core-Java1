package com.practice28;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Employee {

	public static void main(String[] args) {
		Map<String, Integer> hm=new HashMap<>();
		hm.put("virat", 18);
		hm.put("Rohit", 45);
		hm.put("Rahul", 33);
		hm.put("malinga", 20);
		hm.put("bhuvi", 81);
		hm.put("bumrah", 28);
		hm.put("rishabh", 46);
		
//using lambada expressin	
hm.forEach((m,n)->{
	System.out.print(m);
	System.out.print("=>");
	System.out.println(n);

});		
System.out.println("----------------------");
//by using iterate keyset

for(String mmm:hm.keySet()) {
	System.out.println(mmm+"=>"+hm.get(mmm));
}
System.out.println("====================");

//by using hashnext & next method
Iterator<String> pp=hm.keySet().iterator();
while(pp.hasNext()) {
	String key=pp.next();
	System.out.println(key+"=>"+hm.get(key));
}

	}

}
