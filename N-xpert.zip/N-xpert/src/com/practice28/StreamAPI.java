package com.practice28;

import java.util.List;
import java.util.stream.Collectors;

public class StreamAPI {

	public static void main(String[] args) {
		
		List<Integer> al=List.of(10,11,32,85,78,96,45,63,74);
		
//by using for each method
	al.forEach(w->{
		System.out.print(w+" ");
	});
//by using refernce method 
		al.forEach(System.out::println);
System.out.println("NUMBER SORTING>");
//using sorted method and shorting a number
al.stream().sorted().forEach(System.out::println);
		
//using filter method and shorting even number
	List<Integer> list1=al.stream().filter(i->i%2==0).collect(Collectors.toList());
	System.out.println(list1);

	System.out.println("---------------------------------");
//using filter method and shorting odd number
	List<Integer> list2=al.stream().filter(a->a%2!=0).collect(Collectors.toList());
	System.out.println(list2);
	
//max number
	Integer list3=al.stream().max((a,b)-> a.compareTo(b)).get();
	System.out.println("MAXIMUM NUMBER----------"+list3);
	
//min number
	Integer list4=al.stream().min((c,d)->c.compareTo(d)).get();
	System.out.println("MINIMUM NUMBER----------"+list4);
	
//more than 20
	List<Integer> list5=al.stream().filter(m->m>20).collect(Collectors.toList());
	System.out.println("MORE THAN 20----"+list5);
	
//by using map method and number of squere 

List<Integer> list6=al.stream().map(m->m*m).collect(Collectors.toList());
System.out.println("NUMBER OF SQUARE---"+list6);
	}

}
