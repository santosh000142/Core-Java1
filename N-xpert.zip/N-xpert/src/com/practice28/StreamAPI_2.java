package com.practice28;

import java.util.Arrays;
import java.util.List;

public class StreamAPI_2 {

	public static void main(String[] args) {
  List<String> sub=Arrays.asList("math","chemistry","physics","Biology","zology");
  
  //by using for each method 
  sub.forEach(e->{
	  System.out.println(e);
  });
System.out.println("-------------------");

//by using refernce method 
sub.forEach(System.out::println);

//sorting subject 
System.out.println("------sorting subject--------");
sub.stream().sorted().forEach(System.out::println);

 
	}

}
