package com.practice28;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Student_controller {

	
	public static void main(String[] args) {
		
	List<Student> al=new ArrayList<>();
	
al.add(new Student(10, "virat", 102));
al.add(new Student(11, "rohit", 112));
al.add(new Student(15, "malinga", 122));
al.add(new Student(18, "surya", 109));
al.add(new Student(19, "sharma", 108));
al.add(new Student(13, "bhuvi", 106));
al.add(new Student(6, "yuraj", 132));

//for loop
for (int i = 0; i < al.size(); i++) {
	System.out.println(al.get(i));
}
//for each loop
System.out.println("--------------------------------------");
for(Student kk:al) {
	System.out.println(kk);
}
//foreach method
System.out.println("--------------------------------------");
al.forEach(e->{
	System.out.println(e);
});
System.out.println("----------------------------------------");

//iterate the using method hashnext and next method

Iterator<Student> mm=al.iterator();
while(mm.hasNext()) {
	System.out.println(mm.next());
}
System.out.println("=========================================");
//by using refernce method
al.forEach(System.out::println);

}
}


