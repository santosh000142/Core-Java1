package com.runnableinterface01;

public class EvenThread implements Runnable {

	@Override
	public void run() {
		for(int i=1;i<=100;i++) {
	    if(i%2==0) {
		try {
	    Thread.sleep(500);
	} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
				}
	System.out.println("Even number-"+i);
			}
		}
		
	}

}
