package com.runnableinterface01;

public class EvenThread1 {

	public static void main(String[] args) {
		
		 Runnable kk=()-> {
		for(int i=1;i<=50;i++) {
			if(i%2==0) {
				System.out.println("Even no-"+i);
			}
		}
	};
	new Thread(kk).start();
	}
}
