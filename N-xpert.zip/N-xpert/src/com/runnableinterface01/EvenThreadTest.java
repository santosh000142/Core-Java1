package com.runnableinterface01;

public class EvenThreadTest {

	public static void main(String[] args) {
		
		EvenThread kk=new EvenThread();
		Thread th=new Thread(kk);
		th.start();
	}

}
