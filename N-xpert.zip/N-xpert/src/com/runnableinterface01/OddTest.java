package com.runnableinterface01;

public class OddTest {

	public static void main(String[] args) {
		OddThread mm=new OddThread();
		Thread th=new Thread(mm);
		th.setName("odd number");
		
		th.start();

	}

}
