package com.runnableinterface01;

public class OddThread implements Runnable{

	@Override
	public void run() {
		for(int i=1;i<=100;i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			if(i%2==1) {
				System.out.println("odd number-"+i);
			}
		}
		
	}

	
}
