package com.runnableinterface01;

public class Thread1 {

	public static void main(String[] args) throws InterruptedException  {
	
//by using lambda expression
		
		Runnable th=()->{
			for (int i = 1; i <=10; i++) {
				System.out.println("NXSOL--"+i);
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}
		};
		Thread t=new Thread(th);
		t.setName("NXSOL");
		t.start();
		
//creating multiple thread	
		
	for(int j=11;j<=20;j++) {
	Thread.sleep(500);
    System.out.println("Start--"+j);
		}
		
		}}
		
	

		
