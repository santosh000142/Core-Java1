package com.runnableinterface01;

public class Thread2 implements Runnable{

	//without lambda using runnable interface
	
	
	         @Override
	          public void run() {
		      for(int i=1;i<=50;i++) {
			  try {
			   Thread.sleep(450);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			}
			System.out.println("NXSOL--"+i);
		}}
		public static void main(String[] args) {
			
			
			Thread2 tt=new Thread2();
			Thread tt2=new Thread(tt);
			tt2.start();
			
		}

	
	}
	

	

	


