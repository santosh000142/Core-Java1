package com.singleinheritance03;

public class A {

	public void m1() {
		System.out.println("hallo world");
		
	}
}
