package com.singleinheritance03;

public class B extends A{

	public void m2() {
		System.out.println("hallo india");
		System.out.println("welcome to N- xpert solution");
	}
}
