package com.singleinheritance03;

public class Company {

	
	long salary=50000;
}
