package com.singleinheritance03;

public class Employee extends Company {

	float bonus=10000;
	
	public static void main(String[] args) {
		Employee ee=new Employee();
		System.out.println("salary of company -"+ee.salary);
		System.out.println("bonus of employee--"+ee.bonus);

	}

}
