package com.singleinheritance03;

public class Test {

	public static void main(String[] args) {
		B b=new B();
		b.m1();
		b.m2();
	}

}
